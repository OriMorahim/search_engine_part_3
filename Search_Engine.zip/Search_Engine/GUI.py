class GUI:
    pass
